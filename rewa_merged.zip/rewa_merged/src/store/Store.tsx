import { configureStore } from "@reduxjs/toolkit";
import currentUserReducer from "./features/currentUserSlice";

const store = configureStore({
  reducer: {
    currentUserReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export default store;
