import { useLayoutEffect, useState } from "react";
import { UseDispatch, useSelector, UseSelector } from "react-redux";
import { RootState } from "../store/Store.tsx";
import { Navigate } from "react-router-dom";

const Home = () => {
  const user = useSelector(
    (state: RootState) => state.currentUserReducer.currentUser
  );

  if (user === "") {
    return <Navigate to="/" replace={true} />;
  } else {
    return <div>Hello</div>;
  }
};

export default Home;
